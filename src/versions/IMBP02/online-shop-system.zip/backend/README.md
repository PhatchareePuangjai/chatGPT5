
# Backend Setup

1. Install Node.js from https://nodejs.org/

2. Install PostgreSQL and create database:

CREATE DATABASE onlineshop;

Then run:

CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE stock_history (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES products(id),
    change_amount INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

3. Inside backend folder run:

npm install
node server.js
