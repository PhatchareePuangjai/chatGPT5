
const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "onlineshop",
  password: "password",
  port: 5432,
});

app.get("/products", async (req, res) => {
  const result = await pool.query("SELECT * FROM products ORDER BY id");
  res.json(result.rows);
});

app.post("/products", async (req, res) => {
  const { name, price, stock } = req.body;
  const result = await pool.query(
    "INSERT INTO products (name, price, stock) VALUES ($1,$2,$3) RETURNING *",
    [name, price, stock]
  );
  res.json(result.rows[0]);
});

app.post("/buy/:id", async (req, res) => {
  const { id } = req.params;
  const { quantity } = req.body;

  const client = await pool.connect();

  try {
    await client.query("BEGIN");
    const productRes = await client.query(
      "SELECT * FROM products WHERE id=$1 FOR UPDATE",
      [id]
    );

    if (productRes.rows.length === 0) {
      throw new Error("Product not found");
    }

    const product = productRes.rows[0];

    if (product.stock < quantity) {
      throw new Error("Not enough stock");
    }

    const newStock = product.stock - quantity;

    await client.query(
      "UPDATE products SET stock=$1 WHERE id=$2",
      [newStock, id]
    );

    await client.query(
      "INSERT INTO stock_history (product_id, change_amount) VALUES ($1,$2)",
      [id, -quantity]
    );

    if (newStock < 5) {
      console.log(`LOW STOCK: ${product.name} (${newStock} left)`);
    }

    await client.query("COMMIT");
    res.json({ message: "Purchase successful" });

  } catch (err) {
    await client.query("ROLLBACK");
    res.status(400).json({ error: err.message });
  } finally {
    client.release();
  }
});

app.listen(5000, () => console.log("Backend running on http://localhost:5000"));
