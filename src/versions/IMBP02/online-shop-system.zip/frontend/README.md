
# Frontend

No installation needed.

After backend is running:

Double-click index.html

The shop will open in your browser.
