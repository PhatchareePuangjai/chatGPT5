
import React from "react";
import InventoryDashboard from "./InventoryDashboard";

function App() {
  return (
    <div>
      <InventoryDashboard />
    </div>
  );
}

export default App;
