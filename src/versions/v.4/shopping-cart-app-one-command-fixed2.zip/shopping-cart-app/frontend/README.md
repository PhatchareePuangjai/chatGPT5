# Frontend

```bash
cp .env.example .env
npm install
npm run dev
```

Set `VITE_API_URL` in `.env` if your backend is not `http://localhost:4000`.
