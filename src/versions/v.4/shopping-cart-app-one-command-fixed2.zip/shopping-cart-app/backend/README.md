# Backend

```bash
cp .env.example .env
npm install
npm run db:migrate
npm run db:seed
npm run dev
```
