# Shopping Cart (Precise Cents + Stock Guard)

## Run
```bash
docker compose up --build
```

Frontend: http://localhost:8080  
Backend health: http://localhost:3000/api/health
